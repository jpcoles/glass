Simple interface for using GLPK in Python.

This requires GLPK to be installed, and uses the SWIG package for
producing the API.

Notice that the glpk's C keyword 'in' is renamed '_in' in Python, for
avoiding conflict.
